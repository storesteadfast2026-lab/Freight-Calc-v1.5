﻿STH FREIGHT CALCULATOR - AI REVIEW PACKAGE
Generated: 2026-07-28 08:25:01 +09:30
Project root used: C:\Docker-Projects\Freight-Calc-Nuevo

PURPOSE
This ZIP is intended for complete source-code and architecture review by an AI or another developer.

INCLUDED
- Django/Python application code.
- Original templates, JavaScript and CSS.
- Models, migrations, admin configuration, services and tests.
- Docker and installation configuration found at the project root.
- Documentation and optional reports.
- Controlled reference spreadsheets when found.
- Git state, project tree, Django checks, migration status, non-sensitive database counts and test results.

EXCLUDED FOR SAFETY OR SIZE
- Real .env files and credential files.
- Private keys, certificates and database dumps.
- .git history, virtual environments, caches and generated static files.
- Uploaded media and historical imported files.
- Complete PostgreSQL data.
- Arbitrary spreadsheets. Only the three known reference files may be included.

IMPORTANT
Reference spreadsheets and reports can contain business information. Review the ZIP before sending it outside the organization.
The DATABASE_SUMMARY file contains row counts only, not table contents.
